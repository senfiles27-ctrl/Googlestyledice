package com.example.dicestyle

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DiceScreen() }
    }
}

@Composable
fun DiceScreen() {
    var count by remember { mutableStateOf(1) }
    var results by remember { mutableStateOf(listOf(1)) }
    var manual by remember { mutableStateOf(false) }
    var fixed by remember { mutableStateOf(6) }

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = Color.White) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Dice", fontSize = 20.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = { results = List(count) { 1 } }) { Text("Reset") }
                }

                Spacer(Modifier.height(18.dp))

                Text("Dice roller", fontSize = 28.sp)
                Spacer(Modifier.height(18.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = { count = (count - 1).coerceAtLeast(1) }) { Text("−") }
                    Text("$count", fontSize = 20.sp)
                    OutlinedButton(onClick = { count = (count + 1).coerceAtMost(9) }) { Text("+") }
                }

                Spacer(Modifier.height(22.dp))

                Row(
                    Modifier.fillMaxWidth().wrapContentHeight(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    results.forEach { value ->
                        DieFace(value, Modifier.padding(5.dp))
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text("Total: ${results.sum()}", fontSize = 20.sp)

                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = {
                        results = if (manual) List(count) { fixed }
                        else List(count) { Random.nextInt(1, 7) }
                    },
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text("ROLL", fontSize = 17.sp)
                }

                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = manual, onCheckedChange = { manual = it })
                    Spacer(Modifier.width(8.dp))
                    Text("Manual / testing")
                }

                if (manual) {
                    Spacer(Modifier.height(4.dp))
                    Text("Fixed value: $fixed")
                    Slider(
                        value = fixed.toFloat(),
                        onValueChange = { fixed = it.toInt().coerceIn(1, 6) },
                        valueRange = 1f..6f,
                        steps = 4
                    )
                }
            }
        }
    }
}

@Composable
fun DieFace(value: Int, modifier: Modifier = Modifier) {
    Box(
        modifier.size(72.dp)
            .background(Color.White, RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFFBDBDBD), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(value.toString(), fontSize = 34.sp)
    }
}
