# GoogleStyleDice v2

Aplikasi dice roller Android bergaya sederhana seperti hasil pencarian Google.

Fitur:
- 1–9 dadu
- Roll acak 1–6
- Total
- Reset
- Mode Manual/Testing untuk menentukan nilai dadu pada aplikasi ini sendiri

Build:
1. Buka folder ini di Android Studio.
2. Gradle Sync.
3. Build > Build APK(s).
4. APK debug: app/build/outputs/apk/debug/app-debug.apk
